import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auth-change-password-v2',
  templateUrl: './auth-change-password-v2.component.html',
  styleUrls: ['./auth-change-password-v2.component.scss']
})
export class AuthChangePasswordV2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
